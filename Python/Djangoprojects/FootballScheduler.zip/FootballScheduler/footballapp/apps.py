from django.apps import AppConfig


class FootballappConfig(AppConfig):
    name = 'footballapp'
